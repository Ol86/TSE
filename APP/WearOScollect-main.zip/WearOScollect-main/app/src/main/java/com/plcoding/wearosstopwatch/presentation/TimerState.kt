package com.plcoding.wearosstopwatch.presentation

enum class TimerState {
    RUNNING, PAUSED, RESET
}